this is a ftp client for local network only and dos,

connect to the internet with e100pkt.com and dhcp.exe, like ftpsrv.exe on the other dosftp